String.prototype.re = String.prototype.replace;
